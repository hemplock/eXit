<?php

return [
    'ethereum' => [
        'rpc' => env('ETHEREUM_RPC_URL', 'http://localhost:8545')
    ]
];