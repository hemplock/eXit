@extends('layouts.guest-auth')

@section('content')
    <div class="registerAlertHolder">
        ;ojasdf;jsdf
    </div>
@endsection
