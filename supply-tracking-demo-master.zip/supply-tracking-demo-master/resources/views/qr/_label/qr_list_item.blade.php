<li>
    <span class="bold">{{ $iName }}:</span>
    <div class="caption">{{ $iValue }}</div>
</li>