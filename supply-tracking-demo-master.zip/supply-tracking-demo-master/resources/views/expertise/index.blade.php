@extends('layouts.app')

@section('content')

    @include('expertise.index.content-widget')

@endsection