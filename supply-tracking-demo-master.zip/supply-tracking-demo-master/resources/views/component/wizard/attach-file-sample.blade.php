<div class="fileCard hidden" data-section="file-sample">
    <div class="fileInfo">
        <div class="fileIcons">
            <div class="fileIco">
                <span class="fa-stack fa-lg">
                    <span class="fa fa-file fa-stack-2x"></span>
                    <span class="fa fa-paperclip fa-stack-1x text-muted"></span>
                </span>
            </div>
            <a href="#" class="removeBtn detachFile"><i class="fa fa-times"></i></a>
        </div>
        <div class="fileContent">
            <div class="fileType" data-extension></div>
            <div class="qnt" data-size></div>
        </div>
        <div class="fileFooter">
            <input name="docsName[]" type="text" data-file-name="" value="" class="form-control">
        </div>
        <div class="hidden">
            <input type="file" name="docs[]">
        </div>
    </div>
</div>